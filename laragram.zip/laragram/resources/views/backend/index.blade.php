@extends('backend.layouts.app')

@section('content')
<div class="container">
	<h1>Backend</h1>
</div>
@endsection